console.log("Welcome to Internet Basics Homepage!");
let likesCounter = 0;
const likeButton = document.querySelector("#likeButton");

// a function that updates the like button text with the current number of likes
const renderLikesCounter = () => {
    likeButton.innerText = ` (${likesCounter}) Like 👍`;
};

// a function that increments the number of likes by a given number
const addLikes = (num) => {
    likesCounter += num;
    console.log('Likes after adding ' + num + ':', likesCounter);
};

console.log("Initial likes:", likesCounter);
console.log(typeof likesCounter);

likesCounter = likesCounter + 1;
console.log("Likes after increment:", likesCounter);

likesCounter += 1;
console.log("Likes after another increment:", likesCounter);

addLikes(5);
renderLikesCounter();

// event listener for the like button
likeButton.addEventListener("click", () => {
    addLikes(1);
    renderLikesCounter();

    if (likesCounter === 10) {
        alert("🏆 Congratulations! You've reached 10 likes!");
    }
});